#!/usr/bin/env bash

php -S localhost:1234 -t public/