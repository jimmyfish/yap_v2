<?php

/* layouts/layout.html.twig */
class __TwigTemplate_c2ba1a1f2ef17b3666f8545d7baf9f80656688c3df1defa088e5a34410d331da extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<head>
    <meta charset=\"utf-8\">

    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\" />

    <title>YAP! - ";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <!-- Favicon -->
    <link rel=\"shortcut icon\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/images/favicon.ico\" />

    <!-- Google Fonts -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"https://fonts.googleapis.com/css?family=Open+Sans:400,600,700&amp;Raleway:300,400,500,600,700,800,900\">

    <!-- Bootstrap -->
    <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/bootstrap.min.css\">

    <!-- owl-carousel -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/owl-carousel/owl.carousel.css\" />

    <!-- Font Awesome -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/font-awesome.css\" />

    <!-- Magnific Popup -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/magnific-popup/magnific-popup.css\" />

    <!-- Animate -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/animate.css\" />

    <!-- Ionicons -->
    <link rel=\"stylesheet\" href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/ionicons.min.css\">

    <!-- Style -->
    <link rel=\"stylesheet\" href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/style.css\">

    <!-- Responsive -->
    <link rel=\"stylesheet\" href=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/responsive.css\">

    <!-- custom style -->
    <link rel=\"stylesheet\" href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/css/custom.css\" />

</head>

<body>

<!-- loading -->

<div id=\"loading\" class=\"green-bg\">
    <div id=\"loading-center\">
        <div class=\"boxLoading\"></div>
    </div>
</div>

<!-- loading End -->


<!-- Header -->

<header id=\"header-wrap\" data-spy=\"affix\" data-offset-top=\"55\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-12\">
                <nav class=\"navbar navbar-default\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                            <span class=\"sr-only\">Toggle navigation</span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                        </button>
                        <a class=\"navbar-brand\" href=\"#\">
                            <span><img src=\"";
        // line 73
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Logo_YAP.png\" alt=\"logo\"></span>
                            &nbsp;
                            &nbsp;
                            &nbsp;
                            <span><img src=\"";
        // line 77
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/img/Logo_BNI.png\" alt=\"logo\"></span>
                        </a>
                    </div>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    ";
        // line 81
        $context["uriPath"] = $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method"), $this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route_params"), "method"));
        // line 82
        echo "                    <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                        <ul class=\"nav navbar-nav navbar-right\" id=\"top-menu\">
                            <li><a href=\"";
        // line 84
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("home");
        echo "\">Home</a></li>
                            <li><a href=\"";
        // line 85
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("contact");
        echo "\">Contact</a></li>
                            <li><a href=\"";
        // line 86
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("support");
        echo "\">Support</a></li>
                        </ul>
                    </div>
                    <!-- /.navbar-collapse -->
                </nav>
            </div>
        </div>
    </div>
</header>

<!-- Header End -->

";
        // line 98
        $this->displayBlock('content', $context, $blocks);
        // line 99
        echo "
<div class=\"footer\">

    <footer class=\"iq-footer white-bg text-center\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-10 col-md-offset-1\">
                    <div class=\"footer-info iq-mt-50 iq-mb-30\">
                        <img id=\"logo_img\" class=\"img-responsive center-block iq-mb-10 wow zoomIn\" data-wow-duration=\"1s\" src=\"";
        // line 107
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/images/logo-footer.png\" alt=\"\">
                        <p>Menjadi yang terdepan di ranah pembayaran online untuk segmen membawa motivasi baru bagi YAP! untuk mengembangkan bisnisnya lebih luas lagi dan menjangkau konsumen. novasi tanpa batas adalah komitmen YAP! untuk terus menjadi perusahaan pembayaran terdepan, dapat diandalkan dan terus dapat berperan dalam memajukan ekonomi indonesia.</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"footer-copyright iq-ptb-20\">&copy; Hak Cipta <span id=\"copyright\"> <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script></span> PT. Bank Negara Indonesia (Persero), Tbk.</div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Footer END -->

</div>

<script type=\"text/javascript\" src=\"";
        // line 124
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/jquery.min.js\"></script>

<!-- bootstrap -->
<script type=\"text/javascript\" src=\"";
        // line 127
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/bootstrap.min.js\"></script>

<!-- owl-carousel -->
<script type=\"text/javascript\" src=\"";
        // line 130
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/owl-carousel/owl.carousel.min.js\"></script>

<!-- Counter -->
<script type=\"text/javascript\" src=\"";
        // line 133
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/counter/jquery.countTo.js\"></script>

<!-- Jquery Appear -->
<script type=\"text/javascript\" src=\"";
        // line 136
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/jquery.appear.js\"></script>

<!-- Magnific Popup -->
<script type=\"text/javascript\" src=\"";
        // line 139
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/magnific-popup/jquery.magnific-popup.min.js\"></script>

<!-- Retina -->
<script type=\"text/javascript\" src=\"";
        // line 142
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/retina.min.js\"></script>

<!-- wow -->
<script type=\"text/javascript\" src=\"";
        // line 145
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/wow.min.js\"></script>

<!-- Countdown -->
<script type=\"text/javascript\" src=\"";
        // line 148
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/jquery.countdown.min.js\"></script>

<!-- Custom -->
<script type=\"text/javascript\" src=\"";
        // line 151
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/public/assets/js/custom.js\"></script>

<!-- Style Customizer -->
";
        // line 155
        echo "
<!--Start of Tawk.to Script-->
<script type=\"text/javascript\">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
        var s1=document.createElement(\"script\"),s0=document.getElementsByTagName(\"script\")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/59fb1d9dbb0c3f433d4c69e0/default';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
    })();
</script>
<!--End of Tawk.to Script-->
</body>

</html>
";
    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
    }

    // line 98
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layouts/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  289 => 98,  284 => 7,  263 => 155,  257 => 151,  251 => 148,  245 => 145,  239 => 142,  233 => 139,  227 => 136,  221 => 133,  215 => 130,  209 => 127,  203 => 124,  183 => 107,  173 => 99,  171 => 98,  156 => 86,  152 => 85,  148 => 84,  144 => 82,  142 => 81,  135 => 77,  128 => 73,  92 => 40,  86 => 37,  80 => 34,  74 => 31,  68 => 28,  62 => 25,  56 => 22,  50 => 19,  44 => 16,  35 => 10,  29 => 7,  21 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<head>
    <meta charset=\"utf-8\">

    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\" />

    <title>YAP! - {% block title %}{% endblock %}</title>

    <!-- Favicon -->
    <link rel=\"shortcut icon\" href=\"{{ app.request.basepath }}/public/assets/images/favicon.ico\" />

    <!-- Google Fonts -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"https://fonts.googleapis.com/css?family=Open+Sans:400,600,700&amp;Raleway:300,400,500,600,700,800,900\">

    <!-- Bootstrap -->
    <link rel=\"stylesheet\" href=\"{{ app.request.basepath }}/public/assets/css/bootstrap.min.css\">

    <!-- owl-carousel -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ app.request.basepath }}/public/assets/css/owl-carousel/owl.carousel.css\" />

    <!-- Font Awesome -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ app.request.basepath }}/public/assets/css/font-awesome.css\" />

    <!-- Magnific Popup -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ app.request.basepath }}/public/assets/css/magnific-popup/magnific-popup.css\" />

    <!-- Animate -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ app.request.basepath }}/public/assets/css/animate.css\" />

    <!-- Ionicons -->
    <link rel=\"stylesheet\" href=\"{{ app.request.basepath }}/public/assets/css/ionicons.min.css\">

    <!-- Style -->
    <link rel=\"stylesheet\" href=\"{{ app.request.basepath }}/public/assets/css/style.css\">

    <!-- Responsive -->
    <link rel=\"stylesheet\" href=\"{{ app.request.basepath }}/public/assets/css/responsive.css\">

    <!-- custom style -->
    <link rel=\"stylesheet\" href=\"{{ app.request.basepath }}/public/assets/css/custom.css\" />

</head>

<body>

<!-- loading -->

<div id=\"loading\" class=\"green-bg\">
    <div id=\"loading-center\">
        <div class=\"boxLoading\"></div>
    </div>
</div>

<!-- loading End -->


<!-- Header -->

<header id=\"header-wrap\" data-spy=\"affix\" data-offset-top=\"55\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-12\">
                <nav class=\"navbar navbar-default\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                            <span class=\"sr-only\">Toggle navigation</span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                        </button>
                        <a class=\"navbar-brand\" href=\"#\">
                            <span><img src=\"{{ app.request.basepath }}/public/assets/img/Logo_YAP.png\" alt=\"logo\"></span>
                            &nbsp;
                            &nbsp;
                            &nbsp;
                            <span><img src=\"{{ app.request.basepath }}/public/assets/img/Logo_BNI.png\" alt=\"logo\"></span>
                        </a>
                    </div>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    {% set uriPath = path(app.request.attributes.get('_route'), app.request.attributes.get('_route_params')) %}
                    <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                        <ul class=\"nav navbar-nav navbar-right\" id=\"top-menu\">
                            <li><a href=\"{{ path('home') }}\">Home</a></li>
                            <li><a href=\"{{ path('contact') }}\">Contact</a></li>
                            <li><a href=\"{{ path('support') }}\">Support</a></li>
                        </ul>
                    </div>
                    <!-- /.navbar-collapse -->
                </nav>
            </div>
        </div>
    </div>
</header>

<!-- Header End -->

{% block content %}{% endblock %}

<div class=\"footer\">

    <footer class=\"iq-footer white-bg text-center\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-10 col-md-offset-1\">
                    <div class=\"footer-info iq-mt-50 iq-mb-30\">
                        <img id=\"logo_img\" class=\"img-responsive center-block iq-mb-10 wow zoomIn\" data-wow-duration=\"1s\" src=\"{{ app.request.basepath }}/public/assets/images/logo-footer.png\" alt=\"\">
                        <p>Menjadi yang terdepan di ranah pembayaran online untuk segmen membawa motivasi baru bagi YAP! untuk mengembangkan bisnisnya lebih luas lagi dan menjangkau konsumen. novasi tanpa batas adalah komitmen YAP! untuk terus menjadi perusahaan pembayaran terdepan, dapat diandalkan dan terus dapat berperan dalam memajukan ekonomi indonesia.</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"footer-copyright iq-ptb-20\">&copy; Hak Cipta <span id=\"copyright\"> <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script></span> PT. Bank Negara Indonesia (Persero), Tbk.</div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Footer END -->

</div>

<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/jquery.min.js\"></script>

<!-- bootstrap -->
<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/bootstrap.min.js\"></script>

<!-- owl-carousel -->
<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/owl-carousel/owl.carousel.min.js\"></script>

<!-- Counter -->
<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/counter/jquery.countTo.js\"></script>

<!-- Jquery Appear -->
<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/jquery.appear.js\"></script>

<!-- Magnific Popup -->
<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/magnific-popup/jquery.magnific-popup.min.js\"></script>

<!-- Retina -->
<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/retina.min.js\"></script>

<!-- wow -->
<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/wow.min.js\"></script>

<!-- Countdown -->
<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/jquery.countdown.min.js\"></script>

<!-- Custom -->
<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/custom.js\"></script>

<!-- Style Customizer -->
{#<script type=\"text/javascript\" src=\"{{ app.request.basepath }}/public/assets/js/style-customizer.js\"></script>#}

<!--Start of Tawk.to Script-->
<script type=\"text/javascript\">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
        var s1=document.createElement(\"script\"),s0=document.getElementsByTagName(\"script\")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/59fb1d9dbb0c3f433d4c69e0/default';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
    })();
</script>
<!--End of Tawk.to Script-->
</body>

</html>
", "layouts/layout.html.twig", "/home/jimmy/Projects/yap_project_v2/src/Templates/layouts/layout.html.twig");
    }
}
