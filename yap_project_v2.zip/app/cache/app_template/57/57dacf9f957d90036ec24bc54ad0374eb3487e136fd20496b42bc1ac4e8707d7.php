<?php

/* client/contact.html.twig */
class __TwigTemplate_9259ec04f2039956edf9cc5bf50e6377d47e1b8fee461de8cdbe97dd62ae24da extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html.twig", "client/contact.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Hubungi kami";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "    <section id=\"contact-us\" class=\"iq-our-touch iq-bg-fixed iq-over-black-90\" style=\" background: url(";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/assets/img/bg-2.png);\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-10 col-md-offset-1\">
                <div class=\"iq-get-in iq-pall-40 white-bg\">
                    <div class=\"row\">
                        <div class=\"col-sm-12\">
                            <div class=\"heading-title iq-mb-60\">
                                <h2 class=\"title iq-tw-6\">Hubungi kami</h2>
                                <div class=\"divider\"></div>
                                <p>Bila anda mempunyai pertanyaan, keluhan atau kritik dan saran untuk perkembangan Aplikasi pembayaran YAP!, silahkan isi form berikut ini secara lengkap.</p>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div id=\"formmessage\">Success/Error Message Goes Here</div>
                        <form class=\"form-horizontal\" id=\"contactform\" method=\"post\" action=\"\">
                            <div class=\"contact-form\">
                                <div class=\"col-sm-6\">
                                    <div class=\"section-field\">
                                        <input id=\"name\" type=\"text\" placeholder=\"Nama*\" name=\"name\" required>
                                    </div>
                                    <div class=\"section-field\">
                                        <input type=\"email\" placeholder=\"Email*\" name=\"email\" required>
                                    </div>
                                    <div class=\"section-field\">
                                        <input type=\"text\" placeholder=\"Nomor Selular*\" name=\"phone\" required>
                                    </div>
                                </div>
                                <div class=\"col-sm-6\">
                                    <div class=\"section-field textarea\">
                                            <textarea class=\"input-message\" placeholder=\"Pesan*\" rows=\"7\"
                                                      name=\"message\" required></textarea>
                                    </div>
                                    <input type=\"hidden\" name=\"action\" value=\"sendEmail\"/>
                                    <button id=\"submit\" name=\"submit\" type=\"submit\" value=\"Send\"
                                            class=\"button pull-right iq-mt-40\">Kirim pesan
                                    </button>
                                </div>
                            </div>
                        </form>
                        <div id=\"ajaxloader\" style=\"display:none\"><img class=\"center-block mt-30 mb-30\"
                                                                       src=\"images/ajax-loader.gif\" alt=\"\"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </section>
";
    }

    public function getTemplateName()
    {
        return "client/contact.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 6,  35 => 5,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layouts/layout.html.twig' %}

{% block title %}Hubungi kami{% endblock %}

{% block content %}
    <section id=\"contact-us\" class=\"iq-our-touch iq-bg-fixed iq-over-black-90\" style=\" background: url({{ app.request.basepath }}/assets/img/bg-2.png);\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-10 col-md-offset-1\">
                <div class=\"iq-get-in iq-pall-40 white-bg\">
                    <div class=\"row\">
                        <div class=\"col-sm-12\">
                            <div class=\"heading-title iq-mb-60\">
                                <h2 class=\"title iq-tw-6\">Hubungi kami</h2>
                                <div class=\"divider\"></div>
                                <p>Bila anda mempunyai pertanyaan, keluhan atau kritik dan saran untuk perkembangan Aplikasi pembayaran YAP!, silahkan isi form berikut ini secara lengkap.</p>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div id=\"formmessage\">Success/Error Message Goes Here</div>
                        <form class=\"form-horizontal\" id=\"contactform\" method=\"post\" action=\"\">
                            <div class=\"contact-form\">
                                <div class=\"col-sm-6\">
                                    <div class=\"section-field\">
                                        <input id=\"name\" type=\"text\" placeholder=\"Nama*\" name=\"name\" required>
                                    </div>
                                    <div class=\"section-field\">
                                        <input type=\"email\" placeholder=\"Email*\" name=\"email\" required>
                                    </div>
                                    <div class=\"section-field\">
                                        <input type=\"text\" placeholder=\"Nomor Selular*\" name=\"phone\" required>
                                    </div>
                                </div>
                                <div class=\"col-sm-6\">
                                    <div class=\"section-field textarea\">
                                            <textarea class=\"input-message\" placeholder=\"Pesan*\" rows=\"7\"
                                                      name=\"message\" required></textarea>
                                    </div>
                                    <input type=\"hidden\" name=\"action\" value=\"sendEmail\"/>
                                    <button id=\"submit\" name=\"submit\" type=\"submit\" value=\"Send\"
                                            class=\"button pull-right iq-mt-40\">Kirim pesan
                                    </button>
                                </div>
                            </div>
                        </form>
                        <div id=\"ajaxloader\" style=\"display:none\"><img class=\"center-block mt-30 mb-30\"
                                                                       src=\"images/ajax-loader.gif\" alt=\"\"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </section>
{% endblock %}", "client/contact.html.twig", "/home/jimmy/Projects/yap_project/src/Templates/client/contact.html.twig");
    }
}
