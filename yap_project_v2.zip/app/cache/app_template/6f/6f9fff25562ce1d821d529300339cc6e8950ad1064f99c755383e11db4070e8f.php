<?php

/* client/support.html.twig */
class __TwigTemplate_896ecc3e33deff48a1ab3f97b3435c0e0a92ef396ea1bf27a79ad2e386158557 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layouts/layout.html.twig", "client/support.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layouts/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <!-- Frequently Asked Questions -->

    <section class=\"overview-block-ptb white-bg\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Mengapa YAP!</h2>
                        <div class=\"divider\"></div>
                        <p>YAP! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika mnejadikan YAP! bagian dari hidup anda.</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 col-md-6\">
                    <img class=\"img-responsive center-block\" src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/assets/img/Support.png\" alt=\"\">
                </div>
                <div class=\"col-sm-12 col-md-6\">
                    <div class=\"iq-accordion iq-mt-50\">
                        <div class=\"ad-block ad-active\"><a href=\"\" class=\"ad-title iq-tw-6 iq-font-grey\"> <span
                                        class=\"ad-icon\"><i class=\"ion-ios-infinite-outline\" aria-hidden=\"true\"></i></span>Kemudahan bertransaksi</a>

                            <div class=\"ad-details\">
                                <div class=\"row\">
                                    <!-- <div class=\"col-sm-3\"><img alt=\"#\" class=\"img-responsive\" src=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/assets/images/faq-1.jpg\"></div> -->
                                    <div class=\"col-sm-9\">Sistem kami didesain untuk memudahkan Konsumen Anda agar bisa bertransaksi secara Mudah, Aman, Nyaman.
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"ad-block\"><a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\"> <span class=\"ad-icon\"><i
                                            class=\"ion-ios-time-outline\" aria-hidden=\"true\"></i></span>Keamanan lebih utama</a>
                            <div class=\"ad-details\">It has survived not only five centuries, but also the leap into
                                electronic typesetting. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
                                consectetur, adipisci velit.
                            </div>
                        </div>
                        <div class=\"ad-block\"><a href=\"";
        // line 42
        echo "#";
        echo "\" class=\"ad-title iq-tw-6 iq-font-grey\"> <span class=\"ad-icon\"><i
                                            class=\"ion-ios-compose-outline\" aria-hidden=\"true\"></i></span>Solusi Pembayaran Online</a>
                            <div class=\"ad-details\">
                                <div class=\"row\">
                                    <div class=\"col-sm-9\"> It has survived not only five centuries, but also the leap into
                                        electronic typesetting. Neque porro quisquam est, qui dolorem ipsum quia dolor sit
                                        amet, consectetur, adipisci velit.
                                    </div>
                                    <div class=\"col-sm-3\"><img alt=\"#\" class=\"img-responsive\" src=\"";
        // line 50
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "basepath", array()), "html", null, true);
        echo "/assets/images/faq-1.jpg\"></div>

                                </div>
                            </div>
                        </div>
                        <div class=\"ad-block\"><a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\"> <span class=\"ad-icon\"><i
                                            class=\"ion-ios-loop\" aria-hidden=\"true\"></i></span>Top up deposite mudah</a>
                            <div class=\"ad-details\">It has survived not only five centuries, but also the leap into
                                electronic typesetting. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
                                consectetur, adipisci velit.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
";
    }

    public function getTemplateName()
    {
        return "client/support.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 50,  77 => 42,  60 => 28,  48 => 19,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layouts/layout.html.twig' %}

{% block content %}
    <!-- Frequently Asked Questions -->

    <section class=\"overview-block-ptb white-bg\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-sm-12\">
                    <div class=\"heading-title\">
                        <h2 class=\"title iq-tw-6\">Mengapa YAP!</h2>
                        <div class=\"divider\"></div>
                        <p>YAP! adalah aplikasi yang menjadikan pembayaran menjadi lebih mudah. Banyak manfaat yang bisa anda dapatkan ketika mnejadikan YAP! bagian dari hidup anda.</p>
                    </div>
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-sm-12 col-md-6\">
                    <img class=\"img-responsive center-block\" src=\"{{ app.request.basepath }}/assets/img/Support.png\" alt=\"\">
                </div>
                <div class=\"col-sm-12 col-md-6\">
                    <div class=\"iq-accordion iq-mt-50\">
                        <div class=\"ad-block ad-active\"><a href=\"\" class=\"ad-title iq-tw-6 iq-font-grey\"> <span
                                        class=\"ad-icon\"><i class=\"ion-ios-infinite-outline\" aria-hidden=\"true\"></i></span>Kemudahan bertransaksi</a>

                            <div class=\"ad-details\">
                                <div class=\"row\">
                                    <!-- <div class=\"col-sm-3\"><img alt=\"#\" class=\"img-responsive\" src=\"{{ app.request.basepath }}/assets/images/faq-1.jpg\"></div> -->
                                    <div class=\"col-sm-9\">Sistem kami didesain untuk memudahkan Konsumen Anda agar bisa bertransaksi secara Mudah, Aman, Nyaman.
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class=\"ad-block\"><a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\"> <span class=\"ad-icon\"><i
                                            class=\"ion-ios-time-outline\" aria-hidden=\"true\"></i></span>Keamanan lebih utama</a>
                            <div class=\"ad-details\">It has survived not only five centuries, but also the leap into
                                electronic typesetting. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
                                consectetur, adipisci velit.
                            </div>
                        </div>
                        <div class=\"ad-block\"><a href=\"{{ '#' }}\" class=\"ad-title iq-tw-6 iq-font-grey\"> <span class=\"ad-icon\"><i
                                            class=\"ion-ios-compose-outline\" aria-hidden=\"true\"></i></span>Solusi Pembayaran Online</a>
                            <div class=\"ad-details\">
                                <div class=\"row\">
                                    <div class=\"col-sm-9\"> It has survived not only five centuries, but also the leap into
                                        electronic typesetting. Neque porro quisquam est, qui dolorem ipsum quia dolor sit
                                        amet, consectetur, adipisci velit.
                                    </div>
                                    <div class=\"col-sm-3\"><img alt=\"#\" class=\"img-responsive\" src=\"{{ app.request.basepath }}/assets/images/faq-1.jpg\"></div>

                                </div>
                            </div>
                        </div>
                        <div class=\"ad-block\"><a href=\"#\" class=\"ad-title iq-tw-6 iq-font-grey\"> <span class=\"ad-icon\"><i
                                            class=\"ion-ios-loop\" aria-hidden=\"true\"></i></span>Top up deposite mudah</a>
                            <div class=\"ad-details\">It has survived not only five centuries, but also the leap into
                                electronic typesetting. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
                                consectetur, adipisci velit.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
{% endblock %}
", "client/support.html.twig", "/home/jimmy/Projects/yap_project/src/Templates/client/support.html.twig");
    }
}
