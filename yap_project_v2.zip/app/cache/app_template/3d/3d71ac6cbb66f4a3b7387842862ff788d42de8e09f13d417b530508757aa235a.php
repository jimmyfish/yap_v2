<?php

/* client/transport.html.twig */
class __TwigTemplate_d6601c07db048280fe636d047cea0de21681600733d302998d663d4e2bef88f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
<head></head>
<body>
<h3>Feedback dari : ";
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute(($context["data"] ?? $this->getContext($context, "data")), "name", array()), "html", null, true);
        echo "</h3>

<p>Identitas</p>
<p>Nama : ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute(($context["data"] ?? $this->getContext($context, "data")), "name", array()), "html", null, true);
        echo "</p>
<p>Email : ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute(($context["data"] ?? $this->getContext($context, "data")), "email", array()), "html", null, true);
        echo "</p>
<p>No. Telp : ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["data"] ?? $this->getContext($context, "data")), "phone", array()), "html", null, true);
        echo "</p>
<p>Feedback :</p>
<p>";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["data"] ?? $this->getContext($context, "data")), "message", array()), "html", null, true);
        echo "</p>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "client/transport.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 11,  38 => 9,  34 => 8,  30 => 7,  24 => 4,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<html>
<head></head>
<body>
<h3>Feedback dari : {{ data.name }}</h3>

<p>Identitas</p>
<p>Nama : {{ data.name }}</p>
<p>Email : {{ data.email }}</p>
<p>No. Telp : {{ data.phone }}</p>
<p>Feedback :</p>
<p>{{ data.message }}</p>
</body>
</html>", "client/transport.html.twig", "/home/jimmy/Projects/yap_project_v2/src/Templates/client/transport.html.twig");
    }
}
