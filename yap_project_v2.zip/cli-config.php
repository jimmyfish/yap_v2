<?php
$loader = require __DIR__ . '/vendor/autoload.php';
\Doctrine\Common\Annotations\AnnotationRegistry::registerLoader(array($loader, 'loadClass'));
$config = require __DIR__ . '/app/config.php';
$app = new \Silex\Application($config['common']);
require "public/bootstrap.php";
return \Doctrine\ORM\Tools\Console\ConsoleRunner::createHelperSet($app['orm.em']);